config = dict()

config["HOST"] = "0.0.0.0"
config["PORT"] = 13338
config["DEBUG"] = False
config['UPLOAD_FOLDER'] = 'f/'
config['MAX_CONTENT_LENGTH'] = 40 * 1024 * 1024
config['ALLOWED_EXTENSIONS'] = set(['ass', 'odt', 'docx', 'doc', 'css', 'zip', 'ogg', 'mp3', 'wmv', 'mp4', 'txt', 'webm', 'gif', 'jpeg', 'jpg', 'png','mkv','psd','flac'])
config["THREADED"] = True
config["SITE_DATA"] = {
  "title": "AlienBox"
}
