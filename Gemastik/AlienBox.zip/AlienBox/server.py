#!/usr/bin/env python3
import os, binascii
from flask import (Flask, render_template, render_template_string, request,
                   redirect, url_for, send_from_directory, abort, escape)
from werkzeug import secure_filename
from flask import Markup
import threading
from flask.ext.cache import Cache
from conf import config

app = Flask(__name__)
cache = Cache(app,config={'CACHE_TYPE': 'simple'})

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1] in config['ALLOWED_EXTENSIONS']

def tag_escape(inp):
    return inp.replace('<', '').replace('>', '')

@app.route('/')
def home():
  return render_template('upload.html', page=config["SITE_DATA"])

@app.route('/file', methods=['POST'])
def file():
    name = tag_escape(request.form['name'])
    file = request.files['file']
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)

        randomid = binascii.b2a_hex(os.urandom(16))

        path = os.path.join(config['UPLOAD_FOLDER'], randomid)
        os.mkdir(path)

        fullpath = os.path.join(path, filename)
        
        file.save(fullpath)

        with open("%s.conf" % os.path.join(path, randomid), 'w') as f:
          f.write("%s\n" % filename)
          f.write("%s\n" % name)
          f.close()

        return redirect(url_for('uploaded_file',
                                id=randomid))

@app.route('/f/<id>')
def uploaded_file(id):
    path = os.path.join(config['UPLOAD_FOLDER'], id)

    with open("%s/%s.conf" % (path,id), 'r') as f:
      item = f.read().split('\n')
      file = item[0]
      name = item[1]

    if (name == ""):
      name = "Untitled"

    head = "{% extends 'shell.html' %}{% block body %}<h1 class='title'>AlienBox</h1>"
    info = '''<p>File: %s (%s)</p>
              <p>Link: <a href='/%s''>%s</a></p>
              <p>Download: <a href='/%s/%s''>
              Click here</a></p>''' % (name, file, path, path, path, file) 
    foot = "{% endblock %}"
    template = '%s%s%s' % (head, info, foot)

    return render_template_string(template, page=config["SITE_DATA"])

@app.route('/f/<id>/<filename>')
def get_file(id, filename):
    return send_from_directory(os.path.join(config['UPLOAD_FOLDER'], id),
                               filename)

# Error handling
def error_page(error, code):
  return render_template('error.html', page=config["SITE_DATA"], error=error, code=code)

@app.errorhandler(404)
def page_not_found(e):
    return error_page(error="Check the URL.", code=404), 404

@app.errorhandler(500)
def internal_error(e):
    return error_page(error="Something wrong", code=500), 500

@app.errorhandler(403)
def no_permission(e):
    return error_page(error="You shall not pass", code=403), 403

@app.errorhandler(413)
def too_big(e):
    return error_page(error="Too big", code=413), 413

# Start app
if __name__ == '__main__':
  app.run(
    port=config["PORT"],
    host=config["HOST"],
    debug=config["DEBUG"],
    threaded=config["THREADED"]
  )
